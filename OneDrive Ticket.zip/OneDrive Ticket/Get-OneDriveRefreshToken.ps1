﻿<#
.SYNOPSIS
    Device-code sign-in to Microsoft Graph; prints and caches a refresh token.

.PARAMETER ClientId
    Application (client) ID of your Entra app.

.PARAMETER Tenant
    Authority. Use 'consumers' for a personal Microsoft account OneDrive
    (Gmail / Outlook.com / Hotmail). Use 'common' if you want the account picker.
    Do not use your new Azure tenant GUID when the OneDrive owner is an MSA.

.PARAMETER CachePath
    JSON file used to store access + refresh tokens. Default: .\onedrive-token-cache.json
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$ClientId,

    [string]$Tenant = 'consumers',

    [string]$CachePath = (Join-Path $PSScriptRoot 'onedrive-token-cache.json')
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$LoginBase = "https://login.microsoftonline.com/$Tenant/oauth2/v2.0"
$Scopes    = 'offline_access Files.ReadWrite User.Read'

Write-Host "Authority : $LoginBase" -ForegroundColor DarkGray
Write-Host "Client ID : $ClientId" -ForegroundColor DarkGray
Write-Host "Scopes    : $Scopes" -ForegroundColor DarkGray
Write-Host ""

$dc = Invoke-RestMethod -Method Post -Uri "$LoginBase/devicecode" -Body @{
    client_id = $ClientId
    scope     = $Scopes
}

Write-Host $dc.message -ForegroundColor Cyan
Write-Host ""
try { Set-Clipboard -Value $dc.user_code } catch { }

$deadline = [datetime]::UtcNow.AddSeconds([int]$dc.expires_in)
$interval = [math]::Max(5, [int]$dc.interval)

do {
    Start-Sleep -Seconds $interval
    try {
        $tok = Invoke-RestMethod -Method Post -Uri "$LoginBase/token" -Body @{
            grant_type  = 'urn:ietf:params:oauth:grant-type:device_code'
            client_id   = $ClientId
            device_code = $dc.device_code
        }
        break
    } catch {
        $msg = $_.ErrorDetails.Message
        if ($msg -match 'authorization_pending') { continue }
        if ($msg -match 'slow_down') { $interval += 5; continue }
        throw "Token poll failed: $msg"
    }
} while ([datetime]::UtcNow -lt $deadline)

if (-not $tok) { throw "Device code expired before sign-in completed." }

if (-not $tok.refresh_token) {
    Write-Warning "No refresh_token in the response. The app is missing the offline_access scope, or the account type / authority is wrong."
}

$cache = @{
    client_id     = $ClientId
    tenant        = $Tenant
    access_token  = $tok.access_token
    refresh_token = $tok.refresh_token
    token_type    = $tok.token_type
    expires_in    = $tok.expires_in
    scope         = $tok.scope
    obtained_utc  = [datetime]::UtcNow.ToString('o')
}
$cache | ConvertTo-Json | Set-Content -LiteralPath $CachePath -Encoding UTF8

Write-Host ""
Write-Host "Signed in. Cache written to $CachePath" -ForegroundColor Green
Write-Host "Token scopes: $($tok.scope)"
Write-Host ""
Write-Host "Refresh token (treat like a password):" -ForegroundColor Yellow
Write-Host $tok.refresh_token
Write-Host ""

# Prove the access token can see the drive
$me = Invoke-RestMethod -Headers @{ Authorization = "Bearer $($tok.access_token)" } `
                        -Uri 'https://graph.microsoft.com/v1.0/me?$select=displayName,userPrincipalName,id'
$drive = Invoke-RestMethod -Headers @{ Authorization = "Bearer $($tok.access_token)" } `
                           -Uri 'https://graph.microsoft.com/v1.0/me/drive?$select=id,driveType,quota'
Write-Host "Graph /me : $($me.displayName)  <$($me.userPrincipalName)>"
Write-Host "Drive type: $($drive.driveType)  id=$($drive.id)"

# Return the cache object for callers
[pscustomobject]$cache