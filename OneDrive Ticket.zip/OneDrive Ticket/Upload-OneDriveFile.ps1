﻿<#
.SYNOPSIS
    Upload a local file to Microsoft OneDrive using Microsoft Graph.

.DESCRIPTION
    Supports:
      - Delegated OAuth (device code + refresh token) — works for personal
        Microsoft accounts AND work/school OneDrive
      - App-only client credentials — work/school only; uploads into a
        specific user's drive (requires admin-consented application permission)

    Small files (<= 250 MB) use a single PUT.
    Larger files use a resumable upload session in 3.2 MB chunks
    (multiple of 320 KiB, as required by Graph).

.PARAMETER Path
    Local file to upload.

.PARAMETER DestinationFolder
    OneDrive folder path relative to drive root. Examples:
      "/"                  (root)
      "/Uploads"
      "/Projects/2026"

.PARAMETER DestinationName
    Optional name in OneDrive. Defaults to the local file name.

.PARAMETER ConflictBehavior
    fail | replace | rename   (default: rename)

.PARAMETER AuthMode
    Delegated (default) | AppOnly

.PARAMETER UserUpn
    Required for AppOnly. Target user's UPN, e.g. user@contoso.com

.EXAMPLE
    .\Upload-OneDriveFile.ps1 -Path C:\Reports\q3.pdf

.EXAMPLE
    .\Upload-OneDriveFile.ps1 -Path C:\big.iso -DestinationFolder "/ISOs" -ConflictBehavior replace
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateScript({ Test-Path -LiteralPath $_ -PathType Leaf })]
    [string]$Path,

    [string]$DestinationFolder = "/",

    [string]$DestinationName,

    [ValidateSet('fail', 'replace', 'rename')]
    [string]$ConflictBehavior = 'rename',

    [ValidateSet('Delegated', 'AppOnly')]
    [string]$AuthMode = 'Delegated',

    [string]$UserUpn
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# $IsWindows is automatic only in PowerShell 6+. Windows PowerShell 5.1 throws
# under StrictMode if we read it. Detect the OS without that variable.
$script:OnWindows = [System.Environment]::OSVersion.Platform -eq [System.PlatformID]::Win32NT

function Get-ErrorText {
    param($ErrorRecord)
    foreach ($candidate in @(
        $(if ($ErrorRecord.ErrorDetails -and $ErrorRecord.ErrorDetails.Message) { $ErrorRecord.ErrorDetails.Message }),
        $(if ($ErrorRecord.Exception) { $ErrorRecord.Exception.Message })
    )) {
        if ($candidate) { return [string]$candidate }
    }
    return [string]$ErrorRecord
}

function Get-NotePropertyValue {
    param($Object, [string]$Name, $Default = $null)
    if ($null -eq $Object) { return $Default }
    $prop = $Object.PSObject.Properties[$Name]
    if ($prop) { return $prop.Value }
    return $Default
}

# ---------------------------------------------------------------------------
# Configuration — fill these in after app registration (see README below)
# You can also set env vars: OD_CLIENT_ID, OD_TENANT_ID, OD_CLIENT_SECRET
# ---------------------------------------------------------------------------
$script:ClientId     = if ($env:OD_CLIENT_ID)     { $env:OD_CLIENT_ID }     else { 'YOUR_APPLICATION_CLIENT_ID' }
$script:TenantId     = if ($env:OD_TENANT_ID)     { $env:OD_TENANT_ID }     else { 'common' }   # 'common' | 'consumers' | '<guid>' | 'contoso.onmicrosoft.com'
$script:ClientSecret = if ($env:OD_CLIENT_SECRET) { $env:OD_CLIENT_SECRET } else { '' }         # only needed for AppOnly or confidential-client delegated

$GraphBase   = 'https://graph.microsoft.com/v1.0'
$LoginBase   = 'https://login.microsoftonline.com'
$TokenCache  = Join-Path $PSScriptRoot 'onedrive-token-cache.json'
$DelegatedScopes = 'offline_access Files.ReadWrite User.Read'

# Chunk size for resumable uploads: MUST be a multiple of 320 KiB
$ChunkSize = 10 * 320 * 1024   # 3,276,800 bytes (~3.2 MB)
$SimpleUploadMaxBytes = 250MB

# ---------------------------------------------------------------------------
function Assert-Config {
    if ([string]::IsNullOrWhiteSpace($script:ClientId) -or $script:ClientId -like 'YOUR_*') {
        throw "Set `$script:ClientId (or env OD_CLIENT_ID) to your Entra app Application (client) ID."
    }
    if ($AuthMode -eq 'AppOnly') {
        if ([string]::IsNullOrWhiteSpace($script:ClientSecret)) {
            throw "AppOnly mode requires a client secret (set `$script:ClientSecret or env OD_CLIENT_SECRET)."
        }
        if ([string]::IsNullOrWhiteSpace($UserUpn)) {
            throw "AppOnly mode requires -UserUpn (the OneDrive owner's UPN)."
        }
        if ($script:TenantId -in @('common', 'consumers', 'organizations')) {
            throw "AppOnly mode requires a specific tenant ID or domain, not 'common'/'consumers'."
        }
    }
}

function Save-TokenCache {
    param([hashtable]$Data)
    $json = $Data | ConvertTo-Json -Depth 6
    $dir = Split-Path -Parent $TokenCache
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
    # Restrict ACL on Windows when possible
    $json | Set-Content -LiteralPath $TokenCache -Encoding UTF8
    if ($script:OnWindows) {
        try {
            icacls $TokenCache /inheritance:r /grant:r "$($env:USERNAME):(R,W)" | Out-Null
        } catch { }
    }
}

function Read-TokenCache {
    if (-not (Test-Path -LiteralPath $TokenCache)) { return $null }
    try {
        return Get-Content -LiteralPath $TokenCache -Raw | ConvertFrom-Json
    } catch {
        Write-Warning "Could not read token cache: $($_.Exception.Message)"
        return $null
    }
}

function Get-AppOnlyToken {
    $body = @{
        client_id     = $script:ClientId
        client_secret = $script:ClientSecret
        scope         = 'https://graph.microsoft.com/.default'
        grant_type    = 'client_credentials'
    }
    $tok = Invoke-RestMethod -Method Post -Uri "$LoginBase/$($script:TenantId)/oauth2/v2.0/token" -Body $body
    return $tok.access_token
}

function Get-DelegatedToken {
    $cached = Read-TokenCache
    $cachedRefresh = Get-NotePropertyValue $cached 'refresh_token'

    # 1) Try refresh token
    if ($cachedRefresh) {
        try {
            $body = @{
                client_id     = $script:ClientId
                grant_type    = 'refresh_token'
                refresh_token = $cachedRefresh
                scope         = $DelegatedScopes
            }
            if ($script:ClientSecret) { $body.client_secret = $script:ClientSecret }

            $tok = Invoke-RestMethod -Method Post -Uri "$LoginBase/$($script:TenantId)/oauth2/v2.0/token" -Body $body
            $newRefresh = Get-NotePropertyValue $tok 'refresh_token' $cachedRefresh
            Save-TokenCache @{
                access_token  = $tok.access_token
                refresh_token = $newRefresh
                obtained_utc  = [datetime]::UtcNow.ToString('o')
                expires_in    = $tok.expires_in
            }
            Write-Host "Refreshed access token." -ForegroundColor Green
            return $tok.access_token
        } catch {
            Write-Warning "Refresh failed ($(Get-ErrorText $_)). Starting device-code login."
        }
    }

    # 2) Device code flow
    $dcBody = @{
        client_id = $script:ClientId
        scope     = $DelegatedScopes
    }
    $dc = Invoke-RestMethod -Method Post -Uri "$LoginBase/$($script:TenantId)/oauth2/v2.0/devicecode" -Body $dcBody

    Write-Host ""
    Write-Host $dc.message -ForegroundColor Cyan
    Write-Host ""
    if ($dc.user_code) {
        try { Set-Clipboard -Value $dc.user_code -ErrorAction SilentlyContinue } catch { }
    }

    $deadline = [datetime]::UtcNow.AddSeconds([int]$dc.expires_in)
    $interval = [math]::Max(5, [int]$dc.interval)
    do {
        Start-Sleep -Seconds $interval
        try {
            $poll = @{
                grant_type  = 'urn:ietf:params:oauth:grant-type:device_code'
                client_id   = $script:ClientId
                device_code = $dc.device_code
            }
            if ($script:ClientSecret) { $poll.client_secret = $script:ClientSecret }
            $tok = Invoke-RestMethod -Method Post -Uri "$LoginBase/$($script:TenantId)/oauth2/v2.0/token" -Body $poll
            Save-TokenCache @{
                access_token  = $tok.access_token
                refresh_token = (Get-NotePropertyValue $tok 'refresh_token')
                obtained_utc  = [datetime]::UtcNow.ToString('o')
                expires_in    = $tok.expires_in
            }
            Write-Host "Signed in. Refresh token cached at $TokenCache" -ForegroundColor Green
            return $tok.access_token
        } catch {
            $err = Get-ErrorText $_
            if ($err -match 'authorization_pending') { continue }
            if ($err -match 'slow_down') { $interval += 5; continue }
            throw "Device code poll failed: $err"
        }
    } while ([datetime]::UtcNow -lt $deadline)

    throw "Device code expired before sign-in completed."
}

function Get-AccessToken {
    if ($AuthMode -eq 'AppOnly') { return Get-AppOnlyToken }
    return Get-DelegatedToken
}

function Get-AuthHeaders {
    param([string]$Token, [string]$ContentType = 'application/json')
    return @{
        Authorization = "Bearer $Token"
        Accept        = 'application/json'
        'Content-Type' = $ContentType
    }
}

function Get-DriveRootPrefix {
    if ($AuthMode -eq 'AppOnly') {
        return "$GraphBase/users/$([uri]::EscapeDataString($UserUpn))/drive"
    }
    return "$GraphBase/me/drive"
}

function Normalize-FolderPath {
    param([string]$Folder)
    $p = ($Folder -replace '\\', '/').Trim()
    if ([string]::IsNullOrWhiteSpace($p) -or $p -eq '/') { return '' }
    $p = $p.Trim('/')
    return $p
}

function Get-ItemPathUrl {
    param(
        [string]$DrivePrefix,
        [string]$Folder,
        [string]$FileName
    )
    $folder = Normalize-FolderPath $Folder
    $encName = [uri]::EscapeDataString($FileName)
    if ($folder) {
        $encFolder = ($folder -split '/' | ForEach-Object { [uri]::EscapeDataString($_) }) -join '/'
        return "$DrivePrefix/root:/${encFolder}/${encName}:"
    }
    return "$DrivePrefix/root:/${encName}:"
}

function Upload-SmallFile {
    param(
        [string]$Token,
        [string]$ItemUrl,
        [System.IO.FileInfo]$File
    )
    $uri = "$ItemUrl/content"
    # conflictBehavior via query string for simple upload
    $uri += "?@microsoft.graph.conflictBehavior=$ConflictBehavior"
    Write-Host "Simple upload ($([math]::Round($File.Length/1MB, 2)) MB) -> $uri" -ForegroundColor DarkGray
    $headers = @{
        Authorization  = "Bearer $Token"
        'Content-Type' = 'application/octet-stream'
    }
    $item = Invoke-RestMethod -Method Put -Uri $uri -Headers $headers -InFile $File.FullName
    return $item
}

function Upload-LargeFile {
    param(
        [string]$Token,
        [string]$ItemUrl,
        [System.IO.FileInfo]$File
    )
    $sessionUri = "$ItemUrl/createUploadSession"
    $body = @{
        item = @{
            '@microsoft.graph.conflictBehavior' = $ConflictBehavior
            name = $File.Name
        }
    } | ConvertTo-Json

    Write-Host "Creating upload session for $([math]::Round($File.Length/1MB, 2)) MB file..." -ForegroundColor DarkGray
    $session = Invoke-RestMethod -Method Post -Uri $sessionUri -Headers (Get-AuthHeaders $Token) -Body $body

    $uploadUrl = $session.uploadUrl
    $total = $File.Length
    $offset = [int64]0
    $buffer = New-Object byte[] $ChunkSize

    $fs = [System.IO.File]::OpenRead($File.FullName)
    try {
        while ($offset -lt $total) {
            $thisChunk = [int][math]::Min($ChunkSize, $total - $offset)
            $read = $fs.Read($buffer, 0, $thisChunk)
            if ($read -le 0) { break }

            $start = $offset
            $end   = $offset + $read - 1
            $chunk = New-Object byte[] $read
            [Array]::Copy($buffer, $chunk, $read)

            $pct = [math]::Round(100.0 * $end / $total, 1)
            Write-Progress -Activity "Uploading $($File.Name)" -Status "$pct%  ($end / $total bytes)" -PercentComplete $pct

            $headers = @{
                'Content-Length' = $read
                'Content-Range'  = "bytes $start-$end/$total"
            }

            $attempt = 0
            while ($true) {
                $attempt++
                try {
                    $resp = Invoke-WebRequest -Method Put -Uri $uploadUrl -Headers $headers -Body $chunk -UseBasicParsing
                    if ($resp.StatusCode -in 200, 201) {
                        Write-Progress -Activity "Uploading $($File.Name)" -Completed
                        return ($resp.Content | ConvertFrom-Json)
                    }
                    # 202 Accepted = more chunks needed
                    break
                } catch {
                    if ($attempt -ge 5) { throw }
                    $backoff = [math]::Min(30, [math]::Pow(2, $attempt))
                    Write-Warning "Chunk $start-$end failed (attempt $attempt). Retry in ${backoff}s. $($_.Exception.Message)"
                    Start-Sleep -Seconds $backoff
                }
            }
            $offset += $read
        }
    } finally {
        $fs.Dispose()
        Write-Progress -Activity "Uploading $($File.Name)" -Completed
    }

    throw "Upload session finished without a completed driveItem response."
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
Assert-Config

$file = Get-Item -LiteralPath $Path
if (-not $DestinationName) { $DestinationName = $file.Name }

Write-Host "File: $($file.FullName)  ($([math]::Round($file.Length/1MB, 2)) MB)"
Write-Host "Dest: $DestinationFolder / $DestinationName   conflict=$ConflictBehavior   auth=$AuthMode"

$token = Get-AccessToken
$drive = Get-DriveRootPrefix
$itemUrl = Get-ItemPathUrl -DrivePrefix $drive -Folder $DestinationFolder -FileName $DestinationName

if ($file.Length -le $SimpleUploadMaxBytes) {
    $result = Upload-SmallFile -Token $token -ItemUrl $itemUrl -File $file
} else {
    $result = Upload-LargeFile -Token $token -ItemUrl $itemUrl -File $file
}

Write-Host ""
Write-Host "Uploaded:" -ForegroundColor Green
Write-Host "  Name : $($result.name)"
Write-Host "  Id   : $($result.id)"
Write-Host "  Size : $($result.size)"
Write-Host "  Web  : $($result.webUrl)"
$parent = Get-NotePropertyValue $result 'parentReference'
if ($parent) {
    Write-Host "  Path : $((Get-NotePropertyValue $parent 'path'))/$($result.name)"
}

# Return the driveItem so callers can capture it
$result